# WiFi Guardian (Windows 10)

Pequeña aplicación de escritorio para vigilar una Wi-Fi de origen, probar conectividad, y encender el Punto de acceso móvil de Windows cuando Internet funciona y el hotspot está apagado.

## Comportamiento

1. Cada 15 segundos por defecto, revisa si el PC está conectado al SSID configurado.
2. Si no lo está, escanea redes visibles e intenta conectarse usando la contraseña guardada.
3. Hace un ping a la IP de diagnóstico configurada. Es un indicador independiente y no decide por sí solo si existe Internet.
4. Comprueba Internet con una petición HTTP al endpoint de prueba de conectividad de Microsoft.
5. Consulta el estado del Punto de acceso móvil de Windows. Solo si Internet está confirmado y el hotspot está apagado, solicita activarlo mediante `NetworkOperatorTetheringManager`.
6. Repite el ciclo, mostrando un registro de actividad en la ventana.

La contraseña no se guarda en texto plano. Se cifra usando DPAPI con el ámbito del usuario actual de Windows. La configuración está en `%LOCALAPPDATA%\WifiGuardian\settings.xml`.

## Requisitos para compilar

- Windows 10 versión 1709 (compilación 16299) o posterior; para Windows 10 antiguo quizá debas instalar .NET Framework 4.8.
- Visual Studio 2022 con la carga **Desarrollo de escritorio de .NET**.
- Windows 10 SDK 10.0.19041.0 o posterior.
- La extensión/proyecto **Windows Application Packaging Project (MSIX)** de Visual Studio.
- Conectividad de NuGet para restaurar `Microsoft.Windows.SDK.Contracts`.

El proyecto está orientado a .NET Framework 4.8 para evitar exigir un runtime de .NET moderno adicional en instalaciones normales de Windows 10.

## Crear el paquete de prueba

1. Descomprime la carpeta completa en un directorio local.
2. Abre `WifiGuardian.sln` en Visual Studio 2022.
3. Si Visual Studio informa que falta el soporte de proyectos de empaquetado, instala la extensión **MSIX Packaging Tools** o la carga de trabajo correspondiente y vuelve a abrir la solución.
4. Abre una consola de PowerShell en la carpeta descomprimida y ejecuta:

   ```powershell
   powershell -ExecutionPolicy Bypass -File .\Create-Test-Certificate.ps1
   ```

   El script crea un certificado de desarrollo local y lo instala en el almacén del usuario actual. No es un certificado comercial. No uses este mecanismo para distribuir la aplicación a terceros.

5. En Visual Studio, selecciona la plataforma `x64` y compila `WifiGuardian.Package` en `Release`.
6. El paquete `.msix` aparecerá bajo `AppPackages`. Instálalo en ese mismo PC. Si Windows bloquea la instalación, comprueba que el certificado de desarrollo se encuentre en **Certificados - Usuario actual > Personas de confianza**.
7. Ejecuta la aplicación una vez, configura la IP, el SSID y la contraseña, y pulsa **Guardar y comenzar**. Activa la casilla **Iniciar con Windows** si quieres que se abra en los siguientes inicios de sesión. Windows también permite administrar esa opción desde Configuración > Aplicaciones > Inicio o desde el Administrador de tareas.

> Importante: compilar y ejecutar el proyecto WPF sin instalarlo como MSIX sirve para desarrollar la interfaz, pero puede impedir el acceso a la API del hotspot. Para probar la activación real, ejecuta la versión empaquetada, porque el manifiesto declara la capacidad `wiFiControl`.

## Notas y limitaciones

- El campo **IP de diagnóstico** se usa para ICMP/ping. Un equipo puede bloquear ping aun teniendo Internet; por eso el control de Internet usa además la prueba HTTP independiente.
- El hotspot conserva el SSID y la contraseña que estén configurados en Windows. Esta versión no cambia el nombre ni la contraseña de la red que emite el PC.
- La activación depende del soporte del adaptador, los controladores, la configuración de Windows y el perfil de conexión compartido. Si Windows rechaza la operación, se muestra el código de error en el registro.
- La aplicación no apaga el hotspot cuando se pierde Internet; simplemente deja de intentar encenderlo. Así evita interrumpir dispositivos que ya estén conectados.
- Debe permanecer abierta para vigilar la conexión. Al cerrarla, el ciclo de comprobación se detiene.

## Seguridad

La configuración guarda el SSID, la IP y el intervalo, además de la contraseña cifrada por DPAPI para el usuario actual. Si otra cuenta de Windows abre el archivo, no podrá descifrar esa contraseña. El certificado del script es solo para firmar el paquete local de desarrollo y no debe reutilizarse como certificado de distribución.
